import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter as Router } from "react-router-dom";
import "./index.css";
import App from "./App";
import AuthContext from "./store/auth-context";

ReactDOM.render(
  <AuthContext.Provider>
    <Router>
      <App />
    </Router>
  </AuthContext.Provider>,
  document.getElementById("root")
);
